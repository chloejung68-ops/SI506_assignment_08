---
name: resource-summary
description: >
  Build or verify Kura's read-only resource summary when a request mentions a dashboard, summary,
  catalog counts, grouped resource types, or grouped topics. Use it for the summary component and
  route, not for CRUD or CSV interchange changes.
---

# Resource summary

## 1.0 Purpose

This skill repeats Kura's read-only catalog-summary workflow. It follows
`spec-kura-resource-summary.md` while preserving the six supplied Module 08 contracts.

## 2.0 When to Use

Use it when Kura needs total resources or counts grouped by resource type or topic. Do not use it
for CSV import/export or changes to CRUD behavior.

## 3.0 Inputs and Outputs

The input is the existing SQLModel session and its `Resource` rows. The output is a summary mapping
with `total`, `by_type`, and `by_topic`, rendered by `GET /summary`.

## 4.0 Procedure

1. Read the six supplied contracts and `spec-kura-resource-summary.md`.
2. Keep counting logic in `app/resource_summary.py`; accept a `Session` and query `Resource`.
3. Count stored resource types and use `Uncategorized` for a missing topic.
4. Add only the new `/summary` route and shared-shell `summary.html`; pass the exact summary context.
5. Leave CRUD routes, CSV routes, CSV fields, database schema, and UI accessibility behavior intact.

## 5.0 Verification

- `GET /summary` returns 200 and shows the seeded total of 3.
- The page shows `book: 1`, `article: 1`, and `website: 1` for the seed data.
- `uv run ruff format`, `uv run pytest`, `uv run ruff check`, `uv run ty check`, and
  `uv run python test_app.py` all pass.
- `GET /`, `/import`, and `/export` still work, and the summary has no write control.

## 6.0 Supporting Resources

- `spec-kura-resource-summary.md`
- `modules/module_08/module_08/specs/spec-kura.md`
- `modules/module_08/module_08/specs/spec-kura-import_export.md`
- `modules/module_08/module_08/specs/spec-kura-ui.md`
