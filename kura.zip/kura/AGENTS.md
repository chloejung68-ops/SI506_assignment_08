# Kura project context

This file is project context, not an application contract. Six documents in `../../specs/` govern
Module 08:

- `../../specs/reqs-kura.md` and `../../specs/spec-kura.md` define the supplied CRUD baseline;
- `../../specs/reqs-kura-import_export.md` and `../../specs/spec-kura-import_export.md` define the
   import/export extension; and
- `../../specs/reqs-kura-ui.md` and `../../specs/spec-kura-ui.md` define the mandatory presentation
   phase.

Read the governing pair before implementing a phase. If this file disagrees with a governing
document, follow the governing document and correct this context file.

## 1.0 What this is

Kura is a standalone CRUD web application for managing course resources. It stores books, articles,
videos, and websites. The course supplies a complete baseline that can create, read, update, delete,
and search those records. Verify that baseline before extending it; do not rebuild or reinitialize
the project.

## 2.0 Stack and tools

- Python, managed with `uv`.
- **FastAPI** for the web app and routes.
- **SQLModel** for the data model and database access.
- **SQLite** for storage.
- **Jinja2** server-rendered templates for the UI (no JavaScript framework).
- `python-multipart` for HTML form handling; `uvicorn` to run the server.

Run it with: `uv run uvicorn app.main:app --reload`.

## 3.0 Structure (keep it modular)

- `app/models.py`—the `Resource` SQLModel. Data shape only.
- `app/database.py`—engine, session, first-run seeding. The only file that knows about the DB file.
- `app/main.py`—the FastAPI app and CRUD routes.
- `app/templates/`—Jinja2 HTML. It holds `base`, `list`, `form`, and `detail`.

Keep each file to its single responsibility. Do not put database code in templates or HTML in
`main.py`.

## 4.0 Conventions

- Server-rendered pages with HTML-form POSTs—**not** a JSON API.
- Write routes redirect after success (POST → redirect → GET).
- Treat the files in `../../specs/` as contracts and the Module 08 build guide as the implementation
   sequence.
- Prefer clear, readable code over cleverness; this is a learning project.
- After a change, run the app and verify in the browser; the smoke test is `test_app.py`.

## 5.0 The interface to respect

The most common bug is a **route↔template mismatch**: a template uses a variable the route did not
pass (or a different name). When you add or change a route, make sure the template it renders
expects exactly the names you pass in the context dict.

## 6.0 Phase boundaries

Verify the supplied CRUD baseline before the import/export phase. Complete and accept all four
import/export steps before the UI phase. The UI phase changes presentation only; it must not change
a route, context, field, validation, persistence, generated-path, or CSV contract. After accepting
the UI, follow `../spec-kura-build_steps.md` §10.0 to author and discover the two reusable skills
under canonical `.agents/skills/`. If you use Claude Code, copy each canonical skill to its matching
`.claude/skills/<name>/SKILL.md` path. Do not use a symlink. Edit the canonical file first, recopy
it after every revision, and verify that each pair matches byte-for-byte. Launch Claude or Codex
from this Kura project and verify that it discovers both skills. Begin the final audit only after
accepting the skill checkpoint.
