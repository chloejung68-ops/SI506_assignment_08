@AGENTS.md

# Kura—Claude Code additions

`AGENTS.md` above carries this project's whole context: stack, structure, conventions, and the
contracts to respect. Nothing about this application is Claude-specific, so this file adds only the
loading note.

**Claude loads this file lazily** when it first reads a project file. This context does not survive
compaction. Re-read the project `AGENTS.md` after compaction and whenever Claude was launched from a
directory above this project.
