# Kura

Kura means “storehouse” in Japanese. This small CRUD web application manages course resources. It
uses FastAPI, SQLModel, SQLite, and Jinja2 templates. Module 08 supplies this complete CRUD app as
the baseline for the import/export and interface work.

The authoritative application contract is [`../../specs/spec-kura.md`](../../specs/spec-kura.md).

## 1.0 Run it

Read the project context in [`AGENTS.md`](AGENTS.md) before modifying the app. Then set up and start
the supplied baseline:

```bash
cd modules/module_08/work/kura
uv sync
uv run uvicorn app.main:app --reload
```

Then open <http://127.0.0.1:8000/>. The database (`data/generated/resources.db`) is created and
seeded with a few sample resources on first run.

## 2.0 Final project structure

The starter does not ship completed import/export skills. Follow the build sequence in order:
import/export, UI, student-authored skills, then the final audit. After the UI phase is accepted,
follow [the build guide](../spec-kura-build_steps.md) §10.0 to create the skills. The final project
structure is shown below; Codex-only users omit the `.claude/` branch:

```text
kura/
├── .agents/
│   └── skills/
│       ├── import-resources/
│       │   └── SKILL.md   # student-authored canonical import skill
│       └── export-resources/
│           └── SKILL.md   # student-authored canonical export skill
├── .claude/
│   └── skills/             # real matching copies for Claude Code users only
│       ├── import-resources/
│       │   └── SKILL.md
│       └── export-resources/
│           └── SKILL.md
├── pyproject.toml         # dependencies
├── AGENTS.md              # project context (canonical, read by both CLIs)
├── CLAUDE.md              # one-line import of AGENTS.md, read by Claude Code
├── app/
│   ├── models.py          # the Resource SQLModel
│   ├── database.py         # engine, session, first-run seeding
│   ├── csv_io.py           # CSV import/export boundary
│   ├── main.py            # FastAPI app + CRUD and import/export routes
│   └── templates/         # Jinja2 HTML: base, list, form, detail, import
└── data/
    ├── provided/          # read-only import fixtures
    └── generated/         # SQLite database and generated CSV files
```

Keep both student-authored `SKILL.md` files under the canonical `.agents/skills/` directory. If you
use Claude Code, create real matching copies under `.claude/skills/`; never use a symlink. Edit the
canonical file first, recopy it after each revision, and verify that each pair matches byte for
byte. Codex-only users do not need `.claude/skills/`. Follow
[the build guide](../spec-kura-build_steps.md) §10.0 for the complete copy and verification
procedure.

After creating both skills, end any Codex session launched from the course repository root. Relaunch
Codex from this Kura directory with the course profile:

```console
$ cd modules/module_08/work/kura
$ codex --profile umich
```

Run `/skills` and confirm that `import-resources` and `export-resources` both appear before asking
Codex to follow either skill.

## 3.0 Test it

A smoke test exercises the CRUD routes with HTTPX's in-process ASGI transport. No running server is
needed. Run it with the project's test command or directly as a script. Both reset to a freshly
seeded database first. Verify this supplied baseline before adding Module 08 features:

```bash
uv run pytest
uv run python test_app.py
```

## 4.0 Verified stack

The project constrains FastAPI to 0.115.x and Jinja2 to 3.1.x. It also uses SQLModel, Uvicorn, and
python-multipart. The lockfile records the tested dependency versions.
