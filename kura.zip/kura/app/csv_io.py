"""CSV interchange for Kura resources.

This module owns the five-column CSV contract. Routes only choose a path and provide a session.
"""

import csv
from pathlib import Path

from sqlmodel import Session, select

from app.models import Resource

FIELDNAMES = ["title", "resource_type", "url", "topic", "notes"]
RESOURCE_TYPES = {"book", "article", "video", "website"}


def import_resources(path: Path, session: Session) -> dict[str, int]:
    """Import valid rows and commit them once; invalid rows are counted and skipped."""
    with path.open(newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        if reader.fieldnames != FIELDNAMES:
            raise ValueError("CSV header must contain the exact five resource fields")

        imported = 0
        skipped = 0
        for row in reader:
            values = {field: (row[field] or "").strip() for field in FIELDNAMES}
            if not values["title"] or values["resource_type"] not in RESOURCE_TYPES:
                skipped += 1
                continue
            session.add(
                Resource(
                    title=values["title"],
                    resource_type=values["resource_type"],
                    url=values["url"] or None,
                    topic=values["topic"] or None,
                    notes=values["notes"] or None,
                )
            )
            imported += 1
        session.commit()
    return {"imported": imported, "skipped": skipped}


def export_resources(path: Path, session: Session) -> int:
    """Write every resource using the stable five-field interchange contract."""
    resources = session.exec(select(Resource)).all()
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        writer.writeheader()
        for resource in resources:
            writer.writerow(
                {
                    "title": resource.title,
                    "resource_type": resource.resource_type,
                    "url": resource.url or "",
                    "topic": resource.topic or "",
                    "notes": resource.notes or "",
                }
            )
    return len(resources)
