"""The persistence component: the SQLite engine, sessions, and first-run seeding.

This is the only file that knows about the database file and connection. The rest of the
app asks it for a session; it hides the storage details (encapsulation).
"""

from collections.abc import Iterator
from pathlib import Path

from sqlmodel import Session, SQLModel, create_engine, select

from app.models import Resource

# The data/ directory next to the project is split by who writes the file: provided/ holds what
# the project ships and the application only reads, generated/ holds what the application produces
# at run time. The SQLite database is generated, so it lives there.
DATA_DIR = Path(__file__).resolve().parent.parent / "data"
PROVIDED_DIR = DATA_DIR / "provided"
GENERATED_DIR = DATA_DIR / "generated"
GENERATED_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_URL = f"sqlite:///{GENERATED_DIR / 'resources.db'}"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})


def init_db() -> None:
    """Creates the tables if needed and seeds a few resources on first run.

    Safe to call repeatedly: creating tables is idempotent, seeding happens only when the table is
    empty, and the seed rows are constructed fresh on each call so a re-seed after a drop works.
    """
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        if session.exec(select(Resource)).first() is None:
            # Build rows here rather than at module scope. A committed model instance belongs to
            # the session that saved it. Reusing that instance after a reset would not re-seed the
            # empty table.
            session.add_all(
                [
                    Resource(
                        title="Think Python",
                        resource_type="book",
                        url="https://greenteapress.com/wp/think-python-3rd-edition/",
                        topic="Python",
                        notes="A gentle introduction to programming.",
                    ),
                    Resource(
                        title="FastAPI documentation",
                        resource_type="website",
                        url="https://fastapi.tiangolo.com/",
                        topic="Web development",
                        notes="The official FastAPI docs.",
                    ),
                    Resource(
                        title="What Is Computational Thinking?",
                        resource_type="article",
                        url="https://example.edu/computational-thinking",
                        topic="Computational thinking",
                    ),
                ]
            )
            session.commit()


def get_session() -> Iterator[Session]:
    """Yields a database session for one request, closing it afterwards.

    Used as a FastAPI dependency so each route gets a session without managing it by hand.

    Yields:
        Session: An open database session for the duration of one request.
    """
    with Session(engine) as session:
        yield session
