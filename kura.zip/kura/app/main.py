"""The web + logic component: the FastAPI app and the CRUD routes.

Each route is one operation. Read routes render a Jinja template; write routes read an HTML
form, change the database, and redirect. This file talks to the model (app/models.py) and the
database (app/database.py) but does not know how they work inside—it uses their interfaces.
"""

from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlmodel import Session, select

from app.csv_io import export_resources, import_resources
from app.database import get_session, init_db
from app.models import Resource
from app.resource_summary import build_summary

# Create the tables and seed the database on startup.
init_db()

app = FastAPI(title="Kura")
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent / "templates"))

RESOURCE_TYPES = ["book", "article", "video", "website"]


@app.get("/", response_class=HTMLResponse)
def list_resources(
    request: Request, q: str | None = None, session: Session = Depends(get_session)
) -> HTMLResponse:
    """Renders the list page, optionally filtered by a search term.

    Parameters:
        request (Request): The incoming request, required by the template renderer.
        q (str | None): A term matched against a resource's title or topic, or None for no filter.
        session (Session): The database session, injected by FastAPI.

    Returns:
        HTMLResponse: The rendered list page.
    """
    resources = session.exec(select(Resource)).all()
    if q:
        term = q.lower()
        resources = [
            r for r in resources if term in r.title.lower() or (r.topic and term in r.topic.lower())
        ]
    return templates.TemplateResponse(request, "list.html", {"resources": resources, "q": q or ""})


@app.get("/resources/new", response_class=HTMLResponse)
def new_resource_form(request: Request) -> HTMLResponse:
    """Renders an empty form for creating a resource.

    Parameters:
        request (Request): The incoming request, required by the template renderer.

    Returns:
        HTMLResponse: The rendered create form.
    """
    return templates.TemplateResponse(
        request,
        "form.html",
        {"resource": None, "action": "/resources", "types": RESOURCE_TYPES},
    )


@app.post("/resources")
def create_resource(
    title: str = Form(...),
    resource_type: str = Form(...),
    url: str = Form(""),
    topic: str = Form(""),
    notes: str = Form(""),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    """Creates a resource from the submitted form and redirects to the list.

    Parameters:
        title (str): The resource title (required).
        resource_type (str): The kind of resource: book, article, video, or website.
        url (str): The resource URL, or empty if none.
        topic (str): The resource topic, or empty if none.
        notes (str): Free-text notes, or empty if none.
        session (Session): The database session, injected by FastAPI.

    Returns:
        RedirectResponse: A redirect to the list page.
    """
    resource = Resource(
        title=title,
        resource_type=resource_type,
        url=url or None,
        topic=topic or None,
        notes=notes or None,
    )
    session.add(resource)
    session.commit()
    return RedirectResponse("/", status_code=303)


@app.get("/resources/{resource_id}", response_class=HTMLResponse)
def read_resource(
    resource_id: int, request: Request, session: Session = Depends(get_session)
) -> HTMLResponse:
    """Renders the detail page for one resource.

    Parameters:
        resource_id (int): The id of the resource to display.
        request (Request): The incoming request, required by the template renderer.
        session (Session): The database session, injected by FastAPI.

    Returns:
        HTMLResponse: The rendered detail page.

    Raises:
        HTTPException: Raised with status 404 when no resource has the given id.
    """
    resource = session.get(Resource, resource_id)
    if resource is None:
        raise HTTPException(status_code=404, detail="Resource not found")
    return templates.TemplateResponse(request, "detail.html", {"resource": resource})


@app.get("/resources/{resource_id}/edit", response_class=HTMLResponse)
def edit_resource_form(
    resource_id: int, request: Request, session: Session = Depends(get_session)
) -> HTMLResponse:
    """Renders the edit form pre-filled with an existing resource's values.

    Parameters:
        resource_id (int): The id of the resource to edit.
        request (Request): The incoming request, required by the template renderer.
        session (Session): The database session, injected by FastAPI.

    Returns:
        HTMLResponse: The rendered edit form.

    Raises:
        HTTPException: Raised with status 404 when no resource has the given id.
    """
    resource = session.get(Resource, resource_id)
    if resource is None:
        raise HTTPException(status_code=404, detail="Resource not found")
    return templates.TemplateResponse(
        request,
        "form.html",
        {
            "resource": resource,
            "action": f"/resources/{resource_id}/edit",
            "types": RESOURCE_TYPES,
        },
    )


@app.post("/resources/{resource_id}/edit")
def update_resource(
    resource_id: int,
    title: str = Form(...),
    resource_type: str = Form(...),
    url: str = Form(""),
    topic: str = Form(""),
    notes: str = Form(""),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    """Updates an existing resource from the submitted form and redirects to its detail page.

    Parameters:
        resource_id (int): The id of the resource to update.
        title (str): The new title (required).
        resource_type (str): The kind of resource: book, article, video, or website.
        url (str): The resource URL, or empty if none.
        topic (str): The resource topic, or empty if none.
        notes (str): Free-text notes, or empty if none.
        session (Session): The database session, injected by FastAPI.

    Returns:
        RedirectResponse: A redirect to the resource's detail page.

    Raises:
        HTTPException: Raised with status 404 when no resource has the given id.
    """
    resource = session.get(Resource, resource_id)
    if resource is None:
        raise HTTPException(status_code=404, detail="Resource not found")
    resource.title = title
    resource.resource_type = resource_type
    resource.url = url or None
    resource.topic = topic or None
    resource.notes = notes or None
    session.add(resource)
    session.commit()
    return RedirectResponse(f"/resources/{resource_id}", status_code=303)


@app.post("/resources/{resource_id}/delete")
def delete_resource(resource_id: int, session: Session = Depends(get_session)) -> RedirectResponse:
    """Deletes a resource if it exists and redirects to the list.

    Parameters:
        resource_id (int): The id of the resource to delete.
        session (Session): The database session, injected by FastAPI.

    Returns:
        RedirectResponse: A redirect to the list page.
    """
    resource = session.get(Resource, resource_id)
    if resource is not None:
        session.delete(resource)
        session.commit()
    return RedirectResponse("/", status_code=303)


@app.get("/import", response_class=HTMLResponse)
def import_form(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(request, "import.html", {"summary": None})


@app.post("/import", response_class=HTMLResponse)
def import_file(
    request: Request, file: UploadFile = File(...), session: Session = Depends(get_session)
) -> HTMLResponse:
    upload_path = Path(__file__).resolve().parent.parent / "data" / "generated" / "_uploaded.csv"
    upload_path.write_bytes(file.file.read())
    try:
        summary = import_resources(upload_path, session)
    finally:
        upload_path.unlink(missing_ok=True)
    return templates.TemplateResponse(request, "import.html", {"summary": summary})


@app.get("/export")
def export_file(session: Session = Depends(get_session)) -> FileResponse:
    export_path = (
        Path(__file__).resolve().parent.parent / "data" / "generated" / "resources_export.csv"
    )
    export_resources(export_path, session)
    return FileResponse(export_path, media_type="text/csv", filename="resources.csv")


@app.get("/summary", response_class=HTMLResponse)
def resource_summary(request: Request, session: Session = Depends(get_session)) -> HTMLResponse:
    return templates.TemplateResponse(request, "summary.html", {"summary": build_summary(session)})
