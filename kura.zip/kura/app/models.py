"""The data model for Kura—one SQLModel table.

This is the *data model* component: it defines what a resource is. It knows nothing about
web requests or HTML—that separation is the point (modularity).
"""

from sqlmodel import Field, SQLModel


class Resource(SQLModel, table=True):
    """A course resource (a book, article, video, or website) stored in the database.

    Each field becomes a column. ``id`` is the primary key, assigned by the database.
    """

    id: int | None = Field(default=None, primary_key=True)
    title: str
    resource_type: str  # book | article | video | website
    url: str | None = None
    topic: str | None = None
    notes: str | None = None
