"""Read-only catalog summary calculations."""

from collections import Counter

from sqlmodel import Session, select

from app.models import Resource


def build_summary(session: Session) -> dict[str, object]:
    """Return total resources and counts grouped by type and topic."""
    resources = session.exec(select(Resource)).all()
    by_type = Counter(resource.resource_type for resource in resources)
    by_topic = Counter(resource.topic or "Uncategorized" for resource in resources)
    return {
        "total": len(resources),
        "by_type": dict(sorted(by_type.items())),
        "by_topic": dict(sorted(by_topic.items())),
    }
