# Generated data

**The application writes here.** This directory holds data Kura produces at run time: its SQLite
database, created on first start by `app/database.py` and rebuilt if you delete it.

It ships empty, and that is deliberate: producing these files is what running the application does.
Delete anything here and the application rebuilds it on the next run.

`data/provided/` holds the other half—the sample data the project ships, which this application does
not change. The supplied CRUD baseline does not read those files; the Module 08 import/export
extension adds that boundary. Keeping the two directories apart prevents the application from
overwriting its input fixtures.
