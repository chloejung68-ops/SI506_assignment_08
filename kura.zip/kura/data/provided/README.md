# Provided data

**This directory is for input files; the application does not write to them.**

The supplied CRUD baseline starts with this directory empty. The Module 08 build instructions copy
`resources.csv` and `class_resources.csv` here from the module's read-only `data/provided/`
directory before the import/export phase. The import extension reads these project-local copies
without changing the module fixtures.

`data/generated/` holds the other half—what the application produces at run time.
