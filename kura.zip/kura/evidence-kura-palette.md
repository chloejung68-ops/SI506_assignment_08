# Kura palette evidence

## 1.0 Palette change

The supplied mint palette was replaced with a cool, readable blue palette. Changed roles are
accent `#14675c` → `#345995`, page `#f6f8f5` → `#f4f7fb`, tint `#e6f2ec` → `#e4edf8`, badge text
`#265b51` → `#244c78`, danger text `#9b352e` → `#8d2f3b`, and danger border `#b04740` → `#a23b46`.
Text is `#243047`, muted text is `#5f6b7a`, and lines are `#d9e0ea`. Dark text on the page,
accent on white, white on accent, and badge text on tint were checked with a WCAG contrast
calculator; each is above 4.5:1 for text. Focus remains a 3 px accent outline, and Delete remains
text-labelled, so color is not the only meaning.

## 2.0 Commands and observations

From the Kura root, formatter, pytest, Ruff, ty, and the direct smoke test all passed. The stylesheet
contains the required responsive table wrapper and focus rules. Direct browser-width and
keyboard-only observation remains to be completed in a browser environment; this container's
network policy blocked the local HTTP client used for that check.
