# Kura resource summary evidence

## 1.0 Step matrix

| Step | Authorized versus actual files | Focused check | Accumulated result | Decision | Stop |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `app/resource_summary.py`, `test_app.py`; matched | Seeded total 3 and grouped counts | format, pytest, Ruff, ty, smoke passed | accept | yes |
| 2 | `app/main.py`, `summary.html`, `test_app.py`; matched | `GET /summary` returned 200 and counts | format, pytest, Ruff, ty, smoke passed | accept | yes |
| 3 | `list.html`; matched | Link navigated and page stayed read-only | format, pytest, Ruff, ty, smoke passed | accept | yes |

## 2.0 Human evidence

The ASGI route checks showed total `3`, with one book, one article, and one website. Automated tests
also kept the list, import form, and CSV download available. A browser walkthrough remains pending;
the server started successfully, but local HTTP requests were blocked by the container policy.
