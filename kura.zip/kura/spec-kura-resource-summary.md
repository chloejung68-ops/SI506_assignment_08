# Kura resource summary specification

## 1.0 Authority and preservation

This specification adds one read-only catalog summary to Kura. The six supplied contracts in
`modules/module_08/module_08/specs/` remain authoritative for CRUD, CSV import/export, and UI.
The personalized light palette in `base.html` takes precedence only over the literal color values
allowed by Assignment 08 §1.1. No inherited route, context, field, validation rule, persistence
behavior, CSV field, or generated path may change.

## 2.0 Component and interface

`app/resource_summary.py` is the summary component. `build_summary(session)` accepts the existing
SQLModel `Session` interface and returns `total`, `by_type`, and `by_topic` mappings. It hides the
query and counting details from the route. `GET /summary` calls it and renders `summary.html` with
the exact context `{"summary": summary}`. The route is read-only and has no form or mutation.

## 3.0 Workflow and state

The route reads the current `Resource` rows, selects their type and topic values, transforms them
with counters, and writes the result into a server-rendered page. It does not alter catalog state;
CRUD and CSV operations are the operations that establish the state being observed. Resource IDs
are untouched, and repeated requests produce the same counts for the same database state.

## 4.0 Bounded build steps

1. Add `resource_summary.py` and its focused test. Check seeded totals and grouped counts. Stop
   before changing routes or templates.
2. Add `/summary` in `main.py` and `summary.html`. Check status 200, total, type, and topic counts.
   This depends on Step 1; stop before changing inherited routes.
3. Add the summary link to `list.html`, run the full accumulated checks, and inspect the page at
   desktop and narrow widths. Stop with no JavaScript, database schema, or CSV changes.
