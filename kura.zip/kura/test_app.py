"""Verifies the Kura route contracts through HTTPX's in-process ASGI transport.

Run this module with ``uv run pytest`` or directly with ``uv run python test_app.py``. Both paths
reset the database before each check, so the smoke test is repeatable.
"""

from collections.abc import Callable
from unittest.mock import patch

import anyio
import httpx
import pytest
from sqlmodel import Session, SQLModel, select

from app.csv_io import import_resources
from app.database import engine, init_db
from app.main import app
from app.models import Resource


def reset_db() -> None:
    """Drops, recreates, and seeds the schema for an independent check."""
    SQLModel.metadata.drop_all(engine)
    init_db()


def request(
    method: str,
    path: str,
    *,
    data: dict[str, str] | None = None,
    follow_redirects: bool = False,
) -> httpx.Response:
    """Sends one in-process HTTP request to the FastAPI application.

    Parameters:
        method (str): The HTTP method, such as GET or POST.
        path (str): The application path to request.
        data (dict[str, str] | None): Optional HTML form values.
        follow_redirects (bool): Whether HTTPX should follow redirect responses.

    Returns:
        httpx.Response: The application's response.
    """

    async def run_sync_inline(
        function: Callable[..., object], *args: object, **_: object
    ) -> object:
        """Runs one short synchronous FastAPI operation without a worker thread."""
        return function(*args)

    async def send() -> httpx.Response:
        """Sends the request through HTTPX's asynchronous ASGI transport."""
        transport = httpx.ASGITransport(app=app)
        # The course container can deadlock when this in-process test sends FastAPI's short,
        # synchronous route functions to worker threads. Running them inline keeps the test on one
        # event loop; Uvicorn still uses FastAPI's normal execution path when the app is served.
        with patch("anyio.to_thread.run_sync", run_sync_inline):
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://testserver",
                follow_redirects=follow_redirects,
            ) as client:
                return await client.request(method, path, data=data)

    return anyio.run(send)


@pytest.fixture(autouse=True)
def fresh_db() -> None:
    """Gives every pytest check a freshly seeded database."""
    reset_db()


def test_list_route_and_search_contract() -> None:
    """Checks the list route, title and topic search, retained query, and empty result."""
    response = request("GET", "/")
    assert response.status_code == 200
    assert "Think Python" in response.text
    assert "FastAPI documentation" in response.text
    assert "What Is Computational Thinking?" in response.text

    title_response = request("GET", "/?q=PYTHON")
    assert title_response.status_code == 200
    assert "Think Python" in title_response.text
    assert "FastAPI documentation" not in title_response.text
    assert 'value="PYTHON"' in title_response.text

    topic_response = request("GET", "/?q=WEB%20DEVELOPMENT")
    assert topic_response.status_code == 200
    assert "FastAPI documentation" in topic_response.text
    assert "Think Python" not in topic_response.text

    empty_response = request("GET", "/?q=no-such-resource")
    assert empty_response.status_code == 200
    assert "No resources found." in empty_response.text


def test_new_resource_form_contract() -> None:
    """Checks the create form's controls, choices, required title, and action."""
    response = request("GET", "/resources/new")

    assert response.status_code == 200
    assert '<form method="post" action="/resources">' in response.text
    assert 'name="title" value="" required' in response.text
    assert 'name="resource_type"' in response.text
    assert 'name="url"' in response.text
    assert 'name="topic"' in response.text
    assert 'name="notes"' in response.text
    for resource_type in ("book", "article", "video", "website"):
        assert f'value="{resource_type}"' in response.text


def test_create_resource_contract() -> None:
    """Checks create redirect, persistence, optional normalization, display, and validation."""
    response = request(
        "POST",
        "/resources",
        data={
            "title": "Test Video",
            "resource_type": "video",
            "url": "",
            "topic": "",
            "notes": "",
        },
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["location"] == "/"

    with Session(engine) as session:
        resource = session.exec(select(Resource).where(Resource.title == "Test Video")).one()
        assert resource.resource_type == "video"
        assert resource.url is None
        assert resource.topic is None
        assert resource.notes is None

    assert "Test Video" in request("GET", "/").text
    missing_title = request("POST", "/resources", data={"resource_type": "video"})
    assert missing_title.status_code == 422


def test_detail_route_contract() -> None:
    """Checks the detail route for existing, missing, and invalid identifiers."""
    response = request("GET", "/resources/1")
    assert response.status_code == 200
    assert "Think Python" in response.text
    assert "A gentle introduction to programming." in response.text

    missing_response = request("GET", "/resources/9999")
    assert missing_response.status_code == 404
    assert "Resource not found" in missing_response.text

    invalid_response = request("GET", "/resources/not-an-integer")
    assert invalid_response.status_code == 422


def test_edit_resource_form_contract() -> None:
    """Checks the pre-filled edit form and its missing-record behavior."""
    response = request("GET", "/resources/1/edit")

    assert response.status_code == 200
    assert '<form method="post" action="/resources/1/edit">' in response.text
    assert 'value="Think Python"' in response.text
    assert 'value="book" selected' in response.text

    missing_response = request("GET", "/resources/9999/edit")
    assert missing_response.status_code == 404
    assert "Resource not found" in missing_response.text


def test_update_resource_contract() -> None:
    """Checks update redirect, persistence, optional normalization, and failures."""
    response = request(
        "POST",
        "/resources/1/edit",
        data={
            "title": "Think Python (revised)",
            "resource_type": "book",
            "url": "",
            "topic": "",
            "notes": "",
        },
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["location"] == "/resources/1"

    with Session(engine) as session:
        resource = session.get(Resource, 1)
        assert resource is not None
        assert resource.title == "Think Python (revised)"
        assert resource.url is None
        assert resource.topic is None
        assert resource.notes is None

    assert "Think Python (revised)" in request("GET", "/resources/1").text

    missing_response = request(
        "POST",
        "/resources/9999/edit",
        data={"title": "Missing", "resource_type": "book"},
        follow_redirects=False,
    )
    assert missing_response.status_code == 404
    assert "Resource not found" in missing_response.text

    missing_title = request("POST", "/resources/1/edit", data={"resource_type": "book"})
    assert missing_title.status_code == 422


def test_delete_resource_contract() -> None:
    """Checks exact delete redirects and database state for existing and missing rows."""
    response = request("POST", "/resources/1/delete", follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/"

    with Session(engine) as session:
        assert session.get(Resource, 1) is None
        count_after_delete = len(session.exec(select(Resource)).all())

    missing_response = request("POST", "/resources/9999/delete", follow_redirects=False)
    assert missing_response.status_code == 303
    assert missing_response.headers["location"] == "/"

    with Session(engine) as session:
        assert len(session.exec(select(Resource)).all()) == count_after_delete


def test_seed_is_idempotent() -> None:
    """Checks that repeated startup initialization doesn't duplicate seed rows."""
    init_db()
    with Session(engine) as session:
        assert len(session.exec(select(Resource)).all()) == 3


def test_csv_and_summary_routes() -> None:
    """Checks the new interchange routes and read-only summary component."""
    summary = request("GET", "/summary")
    assert summary.status_code == 200
    assert "Total resources" in summary.text
    assert "3" in summary.text

    export = request("GET", "/export")
    assert export.status_code == 200
    assert export.headers["content-type"].startswith("text/csv")
    assert export.headers["content-disposition"] == 'attachment; filename="resources.csv"'
    assert export.text.splitlines()[0] == "title,resource_type,url,topic,notes"


def test_csv_header_is_exact() -> None:
    """Checks that malformed headers fail before rows are imported."""
    from pathlib import Path

    path = Path("data/generated/test_bad.csv")
    path.write_text("id,title,resource_type,url,topic,notes\n1,Bad,book,,,\n", encoding="utf-8")
    try:
        with Session(engine) as session:
            with pytest.raises(ValueError):
                import_resources(path, session)
            assert len(session.exec(select(Resource)).all()) == 3
    finally:
        path.unlink(missing_ok=True)


if __name__ == "__main__":
    smoke_tests: tuple[Callable[[], None], ...] = (
        test_list_route_and_search_contract,
        test_new_resource_form_contract,
        test_create_resource_contract,
        test_detail_route_contract,
        test_edit_resource_form_contract,
        test_update_resource_contract,
        test_delete_resource_contract,
        test_seed_is_idempotent,
        test_csv_and_summary_routes,
        test_csv_header_is_exact,
    )
    for smoke_test in smoke_tests:
        reset_db()
        smoke_test()
    print("ALL CRUD TESTS PASSED")
